﻿using NodeCanvas.Framework;


namespace NodeCanvas.DialogueTrees
{

    public class DTConnection : Connection
    {

    }
}